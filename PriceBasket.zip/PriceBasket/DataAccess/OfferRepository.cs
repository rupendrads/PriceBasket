﻿using Entities;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DataAccess
{
    public class OfferRepository: IOfferRepository
    {
        private IJsonData _jsonData;

        public OfferRepository(IJsonData jsonData)
        {
            this._jsonData = jsonData;
        }

        public IEnumerable<Offer> GetAll()
        {
            var offers = _jsonData.GetOffers();

            return offers;
        }

        // Additional functios goes here
    }
}
