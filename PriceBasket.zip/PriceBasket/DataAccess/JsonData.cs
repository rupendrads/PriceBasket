﻿using Entities;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Web.Script.Serialization;
using System.Configuration;

namespace DataAccess
{
    public class JsonData : IJsonData
    {        
        string productsFilePath = string.Empty;
        string offersFilePath = string.Empty;

        public JsonData()
        {
            FileHelper fileHelper = new FileHelper();

            productsFilePath = fileHelper.GetFilePath(ConfigurationManager.AppSettings["productsFilePath"]);
            offersFilePath = fileHelper.GetFilePath(ConfigurationManager.AppSettings["offersFilePath"]);
        }

        // parse the json file and get available products
        public IEnumerable<Product> GetProducts()
        {            
            string jsonData = System.IO.File.ReadAllText(productsFilePath); 

            JavaScriptSerializer js = new JavaScriptSerializer();
            IEnumerable<Product> products = js.Deserialize<Product[]>(jsonData);            

            return products;
        }

        // parse the json file and get available offers
        public IEnumerable<Offer> GetOffers()
        {
            string jsonData = System.IO.File.ReadAllText(offersFilePath);

            JavaScriptSerializer js = new JavaScriptSerializer();
            IEnumerable<Offer> offers = js.Deserialize<Offer[]>(jsonData);

            return offers;
        }
    }
}
