﻿using Entities;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DataAccess
{
    public class ProductRepository : IProductRepository
    {
        private IJsonData _jsonData;

        public ProductRepository(IJsonData jsonData)
        {
            this._jsonData = jsonData;
        }

        public IEnumerable<Product> GetAll()
        {                      
            var products = _jsonData.GetProducts();

            return products;
        }

        // Additional functios goes here
    }
}
