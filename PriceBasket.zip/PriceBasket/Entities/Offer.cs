﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Entities
{
    public class Offer
    {
        public string OfferType { get; set; }
        public bool PercentageOff { get; set; }
        public string PercentageOffProduct { get; set; }
        public int Percentage { get; set; }
        public string PurchaseProduct { get; set; }
        public int PurchaseQuantity { get; set; }
        public int PurchaseDiscountQuantity { get; set; }
    }
}
