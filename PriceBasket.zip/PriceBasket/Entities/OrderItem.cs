﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Entities
{
    public class OrderItem
    {
        public int ProductId { get; set; }
        public int ItemsCount { get; set; }

        public Product Product { get; set; }

        public double SellPrice { get; set; }
        public int DiscountPercentage { get; set; }
    }
}
