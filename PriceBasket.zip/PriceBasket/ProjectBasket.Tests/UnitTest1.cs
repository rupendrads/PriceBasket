﻿using System;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using BusinessLogic;
using System.Collections.Generic;
using System.Linq;

namespace PriceBasket.Tests
{
    [TestClass]
    public class UnitTest1
    {
        private IOrderManager getOrderManager()
        {
            return new OrderManager(new ProductsManager(), new Cart(new OfferManager())); 
        }

        [TestMethod]
        public void GetAllProducts()
        {
            // Arrange
            var productManager = new ProductsManager();

            // Act
            var products = productManager.GetProducts();

            // Assert
            Assert.AreEqual(4, products.Count());
        }

        [TestMethod]
        public void GetAllOffers()
        {
            // Arrange
            var offerManager = new OfferManager();

            // Act
            var offers = offerManager.GetOffers();

            // Assert
            Assert.AreEqual(2, offers.Count());
            Assert.IsTrue(offers.Any(o => o.OfferType == "RegularDiscount"));
            Assert.IsTrue(offers.Any(o => o.OfferType == "PurchaseDiscount"));
        }

        [TestMethod]
        public void ParsingQuantityInputAsNumber()
        {
            // Arrange
            var orderManager = getOrderManager();

            // Act
            var quantity = orderManager.ParseQuantity("Apples", "1");

            // Assert            
            Assert.AreEqual(1, quantity);
        }

        [TestMethod]
        [ExpectedException(typeof(Exception), "Invalid quantity for - Apples")]
        public void ParsingQuantityInputAsNotaNumber()
        {
            // Arrange
            var orderManager = getOrderManager();

            // Act
            orderManager.ParseQuantity("Apples", "zzz");            
        }

        [TestMethod]
        public void AddSingleProductToOrder()
        {
            // Arrange
            var orderManager = getOrderManager();

            // Act
            orderManager.AddProduct("Apples", 3);

            // Assert
            ICart cart = orderManager.Cart;
            Assert.AreEqual(1, cart.Order.OrderItems.Count);    
        }

        [TestMethod]
        public void AddMultipleProductsToOrder()
        {
            // Arrange
            var orderManager = getOrderManager();

            // Act
            orderManager.AddProduct("Apples", 3);
            orderManager.AddProduct("Milk", 2);
            orderManager.AddProduct("Bread", 1);
            ICart cart = orderManager.Cart;

            // Assert            
            Assert.AreEqual(3, cart.Order.OrderItems.Count);
        }

        [TestMethod]
        [ExpectedException(typeof(Exception), "Product NOT Found - Orange")]
        public void AddNotAvailableProduct()
        {
            // Arrange
            var orderManager = getOrderManager();

            // Act
            orderManager.AddProduct("Orange", 1);            
        }

        [TestMethod]
        public void WhenNoOffersOnInputProducts()
        {
            // Arrange
            var orderManager = getOrderManager();                        

            // Act
            orderManager.AddProduct("Bread", 1);
            ICart cart = orderManager.Cart;

            // Assert
            Assert.AreEqual(cart.Order.OrderItems.Count(oi => oi.DiscountPercentage > 0), 0);
            Assert.AreEqual(cart.SubTotal, cart.Total);
        }

        [TestMethod]
        public void WhenOffersOnInputProducts()
        {
            // Arrange
            var orderManager = getOrderManager();

            // Act
            orderManager.AddProduct("Apples", 1);
            ICart cart = orderManager.Cart;

            // Assert
            Assert.AreEqual(cart.Order.OrderItems.Count(oi => oi.DiscountPercentage > 0), 1);
            Assert.IsTrue(cart.Total < cart.SubTotal);
            Assert.AreEqual(cart.SubTotal, 1);
            Assert.AreEqual(cart.Total, 0.88);            
            Assert.IsTrue(cart.Order.OrderItems.Any(oi => oi.DiscountPercentage == 12));
        }

        [TestMethod]
        public void WhenPurchaseOffersOnInputProducts()
        {
            // Arrange
            var orderManager = getOrderManager();

            // Act
            orderManager.AddProduct("Soup", 2);
            orderManager.AddProduct("Bread", 1);
            ICart cart = orderManager.Cart;

            // Assert
            Assert.AreEqual(cart.Order.OrderItems.Count(oi => oi.DiscountPercentage > 0), 1);
            Assert.IsTrue(cart.Total < cart.SubTotal);
            Assert.IsTrue(cart.Order.OrderItems.Any(oi => oi.DiscountPercentage == 50));
        }

        [TestMethod]
        public void WhenMultipleOffersOnInputProducts()
        {
            // Arrange
            var orderManager = getOrderManager();

            // Act
            orderManager.AddProduct("Apples", 3);
            orderManager.AddProduct("Soup", 2);
            orderManager.AddProduct("Bread", 1);
            ICart cart = orderManager.Cart;

            // Assert
            Assert.AreEqual(cart.Order.OrderItems.Count(oi => oi.DiscountPercentage > 0), 2);
            Assert.IsTrue(cart.Total < cart.SubTotal);
            Assert.IsTrue(cart.Order.OrderItems.Any(oi => oi.DiscountPercentage == 12));
            Assert.IsTrue(cart.Order.OrderItems.Any(oi => oi.DiscountPercentage == 50));
        }
    }
}
