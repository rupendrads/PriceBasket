﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Entities;
using BusinessLogic;
using Ninject;
using System.Reflection;

namespace PriceBasket
{
    class Program
    {
        // DI - ninject
        internal static IKernel kernel = new StandardKernel();

        static int defaultQauntity = 1;

        static void Main(string[] args)
        {
            // DI container
            kernel.Load(Assembly.GetExecutingAssembly());

            // OrderManager object
            var orderManager = kernel.Get<IOrderManager>();

            try
            {
                // prepare order
                foreach (var arg in args)
                {
                    AddProductToOrder(orderManager, arg);
                }

                // print output
                var print = new Print();
                print.PrintOutput(orderManager.Cart);
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message);
            }
            
            Console.ReadLine();
        }

        private static void AddProductToOrder(IOrderManager orderManager, string nameQuantity)
        {
            // default product name and quantity
            string productName = string.Empty;
            int quantity = defaultQauntity;   // default quantity is 1 if not provided by user                    

            // split product name and quantity
            string[] item = NameQuantitySplitter.Split(nameQuantity);

            // get product name
            productName = item[0];

            if (!string.IsNullOrEmpty(productName))
            {
                // get product quantity
                // if quantity is provided by user then parse it (default is 1)
                if (item.Count() == 2)
                {
                    quantity = orderManager.ParseQuantity(productName, item[1]);
                }

                //add product to order
                orderManager.AddProduct(productName, quantity);
            }
        }
    }
}
