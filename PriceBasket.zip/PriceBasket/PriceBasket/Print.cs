﻿using BusinessLogic;
using System;
using System.Collections.Generic;
using System.Globalization;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PriceBasket
{
    public class Print
    {
        // set cultureinfo
        private static CultureInfo cultureInfo = new CultureInfo("en-GB"); 

        public void PrintOutput(ICart cart)
        {
            // print Subtotoal
            PrintSubtotal(cart);

            // offers if any - print to console
            PrintOffers(cart);

            // print total
            PrintTotal(cart);
        }

        private static void PrintSubtotal(ICart cart)
        {
            if (cart.SubTotal >= 1)
            {
                Console.WriteLine(string.Format(cultureInfo, "Subtotal: {0:C}", cart.SubTotal));
            }
            else
            {
                Console.WriteLine(string.Format("Subtotal: {0}p", cart.SubTotal));
            }
        }

        private static void PrintOffers(ICart cart)
        {
            if (cart.Order.OrderItems.Count(oi => oi.DiscountPercentage > 0) > 0)
            {
                foreach (var orderItem in cart.Order.OrderItems)
                {
                    if (orderItem.DiscountPercentage > 0)
                    {
                        if (orderItem.SellPrice > 1)
                        {
                            Console.WriteLine(string.Format(cultureInfo, "{0} {1}% Off: -{2:C}", orderItem.Product.Name, orderItem.DiscountPercentage, orderItem.SellPrice));
                        }
                        else
                        {
                            Console.WriteLine(string.Format("{0} {1}% Off: -{2}p", orderItem.Product.Name, orderItem.DiscountPercentage, orderItem.SellPrice));
                        }
                    }
                }
            }
            else
            {
                Console.WriteLine("(no offers available)");
            }
        }

        private static void PrintTotal(ICart cart)
        {
            if (cart.Total >= 1)
            {
                Console.WriteLine(string.Format(cultureInfo, "Total: {0:C}", cart.Total));
            }
            else
            {
                Console.WriteLine(string.Format("Total: {0}p", cart.Total));
            }
        }        
    }
}
