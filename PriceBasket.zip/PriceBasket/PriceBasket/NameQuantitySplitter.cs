﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PriceBasket
{
    public static class NameQuantitySplitter
    {
        public static string[] Split(string nameQuantity)
        {
            // name quantity splitter for product
            char nameQuantitysplitter = '-';

            // splitting string for product name and quantity
            string[] item = nameQuantity.Split(new char[] { nameQuantitysplitter });
            return item;
        }
    }
}
