﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Ninject;
using Ninject.Modules;
using BusinessLogic;

namespace PriceBasket
{
    public class DIRegistration: NinjectModule
    {
        public override void Load()
        {
            Bind<IOrderManager>().To<OrderManager>();
            Bind<IOfferManager>().To<OfferManager>();
            Bind<IProductsManager>().To<ProductsManager>();
            Bind<ICart>().To<Cart>();
        }
    }
}
