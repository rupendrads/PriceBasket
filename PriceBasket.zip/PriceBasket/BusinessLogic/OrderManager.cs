﻿using DataAccess;
using Entities;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BusinessLogic
{
    public class OrderManager: IOrderManager
    {
        private Order _order;
        private ICart _cart;
        
        private IProductsManager _productsManager;        
       
        public OrderManager(IProductsManager productManager, ICart cart)
        {
            this._order = new Order();
            this._cart = cart;

            this._productsManager = productManager;            
        }

        public ICart Cart
        {
            get
            {
                // apply offers if any and perform calculation
                this._cart.Calculate(this._order);
                return this._cart;
            }
        }

        // add product to order
        public void AddProduct(string productName, int quantity)
        {
            if (_productsManager.GetProducts().Any(p => p.Name.ToLower() == productName.ToLower()))
            {
                var product = _productsManager.GetProducts().First(p => p.Name.ToLower() == productName.ToLower());

                this._order.OrderItems.Add(new OrderItem
                {
                    Product = product,
                    ItemsCount = quantity
                });
            }
            else
            {
                throw new Exception(string.Format("Product NOT Found - {0}", productName));
            }
        }

        // parse & validate input quantity before product is ordered
        public int ParseQuantity(string productName, string inputQuantity)
        {
            if (!string.IsNullOrEmpty(inputQuantity))
            {
                int result;
                if (int.TryParse(inputQuantity, out result))
                {
                    return result;
                }
                else
                {
                    // all messages can be moved to some other central location
                    throw new Exception(string.Format("Invalid quantity for - {0}", productName));
                }
            }

            return 1;
        }    
    }
}
