﻿using Entities;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BusinessLogic
{
    public class PurchaseDiscount: IDiscount
    {
        public void ApplyDiscount(ICart cart, Entities.Offer offer)
        {
            // get purchased product having offer
            OrderItem orderItem = cart.Order.OrderItems.FirstOrDefault(oi => oi.Product.Name == offer.PurchaseProduct);

            if (orderItem != null)
            {
                // check offer quantity on purchase product
                if (orderItem.ItemsCount >= offer.PurchaseQuantity)
                {
                    // discount applicable count
                    int discountCount = orderItem.ItemsCount / offer.PurchaseQuantity;

                    // if discount is in percentage
                    if (offer.PercentageOff && offer.Percentage > 0)
                    {
                        // get discounted product
                        OrderItem percentageOffProduct = cart.Order.OrderItems.FirstOrDefault(oi => oi.Product.Name == offer.PercentageOffProduct);

                        if (percentageOffProduct != null)
                        {
                            // initial available quantity to apply discount
                            int balanceQuantity = percentageOffProduct.ItemsCount;

                            double discountedPrice = 0;

                            for (int i = 0; i < discountCount; i++)
                            {
                                if (balanceQuantity >= offer.PurchaseDiscountQuantity)
                                {
                                    discountedPrice += (double)offer.PurchaseDiscountQuantity * percentageOffProduct.Product.PricePerUnit * ((double)offer.Percentage / 100);

                                    // current available quantity to apply discount
                                    balanceQuantity = balanceQuantity - offer.PurchaseDiscountQuantity;
                                }
                            }

                            percentageOffProduct.SellPrice = discountedPrice;
                            percentageOffProduct.DiscountPercentage = offer.Percentage;
                        }
                    }
                }
            }
        }
    }
}
