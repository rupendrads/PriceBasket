﻿using DataAccess;
using Entities;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BusinessLogic
{
    public class OfferManager : IOfferManager    
    {
        private IOfferRepository _offerRepository;

        public OfferManager()
        {
            _offerRepository = Factory.CreateOfferRepository();
        }

        public IEnumerable<Offer> GetOffers()
        {
            return _offerRepository.GetAll();
        }

        public void ApplyOffers(ICart cart, IEnumerable<Offer> offers)
        {
            IDiscount discount;

            foreach (var offer in offers)
            {
                discount = Factory.CreateDiscount(offer.OfferType);
                discount.ApplyDiscount(cart, offer);
            }        
        }
    }
}
