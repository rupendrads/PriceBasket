﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Entities;

namespace BusinessLogic
{
    public class Cart: ICart
    {
        private IOfferManager _offerManager;

        public Order Order { get; private set; }

        public double SubTotal { get; private set; }
        public double Total { get; private set; }

        public Cart(IOfferManager offerManager)
        {
            this._offerManager = offerManager;
        }

        public void Calculate(Order order)
        {
            IEnumerable<Offer> offers = this._offerManager.GetOffers();

            // get the updated order
            this.Order = order;

            // calculate subtotal and total
            foreach (var item in Order.OrderItems)
            {
                SubTotal += item.ItemsCount * item.Product.PricePerUnit;
            }
            this.Total = this.SubTotal;

            // apply special offers if any to total 
            if (offers.Count() > 0)
            {
                _offerManager.ApplyOffers(this, offers);

                double discountedPrice = this.Order.OrderItems.Where(oi => oi.SellPrice > 0).Sum(oi => oi.SellPrice);
                this.Total = this.Total - discountedPrice;
            }
        }
    }
}
