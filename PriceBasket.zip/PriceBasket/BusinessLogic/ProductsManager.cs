﻿using Entities;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using DataAccess;

namespace BusinessLogic
{
    public class ProductsManager: IProductsManager
    {
        private IProductRepository _productRepository;

        public ProductsManager()
        {
            _productRepository = Factory.CreateProductRepository();
        }

        public IEnumerable<Product> GetProducts()
        {            
            return _productRepository.GetAll();
        }
    }
}
