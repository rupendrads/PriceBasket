﻿using Entities;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BusinessLogic
{
    public interface ICart
    {
        Order Order { get;}

        double SubTotal { get;}
        double Total { get;}

        void Calculate(Order order);
    }
}
