﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using DataAccess;

namespace BusinessLogic
{
    public static class Factory
    {
        public static IProductRepository CreateProductRepository()
        {
            return new ProductRepository(CreateNewJsonData());
        }

        public static IOfferRepository CreateOfferRepository()
        {
            return new OfferRepository(CreateNewJsonData());
        }

        public static IJsonData CreateNewJsonData()
        {
            return new JsonData();
        }

        public static IDiscount CreateDiscount(string offerType)
        {
            IDiscount discount;            

            switch (offerType)
            {
                case "PurchaseDiscount":
                    discount = new PurchaseDiscount();
                    break;
                default:
                    discount = new RegularDiscount();
                    break;
            }

            return discount;
        }
    }
}
