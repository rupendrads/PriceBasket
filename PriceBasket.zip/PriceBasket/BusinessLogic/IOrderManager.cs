﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BusinessLogic
{
    public interface IOrderManager
    {
        ICart Cart { get; }
        void AddProduct(string productName, int quantity);
        int ParseQuantity(string productName, string inputQuantity);
    }
}
