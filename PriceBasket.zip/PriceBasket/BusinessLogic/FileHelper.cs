﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Reflection;
using System.Text;
using System.Threading.Tasks;

namespace BusinessLogic
{
    public class FileHelper
    {
        public string GetFilePath(string relativePath)
        {
            string filePath;

            // use currently executing assembly directory to find the full path
            Assembly assembly = Assembly.GetExecutingAssembly();
            string assemblyDir = assembly.CodeBase;
            assemblyDir = assemblyDir.Replace("file:///", "");
            assemblyDir = Path.GetDirectoryName(assemblyDir);
            filePath = relativePath.Replace("~", assemblyDir);

            return filePath;
        }
    }
}
