﻿using Entities;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BusinessLogic
{
    public class RegularDiscount: IDiscount
    {
        public void ApplyDiscount(ICart cart, Offer offer)
        {
            if (offer.PercentageOff && offer.Percentage > 0)
            {
                OrderItem orderItem = cart.Order.OrderItems.FirstOrDefault(oi => oi.Product.Name == offer.PercentageOffProduct);

                if (orderItem != null)
                {
                    double totalPrice = (double)orderItem.ItemsCount * orderItem.Product.PricePerUnit;
                    double discountedPrice = totalPrice * ((double)offer.Percentage / 100);

                    orderItem.SellPrice = discountedPrice;
                    orderItem.DiscountPercentage = offer.Percentage;
                }
            }
        }
    }
}
